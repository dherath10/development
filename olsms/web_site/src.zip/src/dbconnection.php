<?php
//To create db connection 

      $con=new mysqli("localhost","root","","olsms"); //Conncection string

